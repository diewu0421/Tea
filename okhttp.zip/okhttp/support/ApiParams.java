package com.zx.tianditong.api.okhttp.support;

import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;

public class ApiParams {
    List<String> names = new ArrayList<>();
    List<String> values = new ArrayList<>();

    public static ApiParams asParam(Object ... values){
        ApiParams param = new ApiParams();
        int center = values.length / 2;
        for (int i = 0; i < center; i++) {
            if(values[center + i] != null)
                param.add(values[i].toString(), values[center + i].toString());
        }
        return param;
    }

    public void add(String name,String value){
        if(name != null && !names.contains(name)){
            names.add(name);
            values.add(value);
        }
    }

    public void add(String name,Object value){
        if(name != null && !names.contains(name)){
            names.add(name);
            values.add(value == null?null:value.toString());
        }
    }

    public int size(){
        return  names.size();
    }

    public String getName(int index){
        if(index < names.size()){
            return  names.get(index);
        }
        return null;
    }

    public String getValue(int index){
        if(index < values.size()){
            return  values.get(index);
        }
        return null;
    }

    public void delete(String name){
        for(int i = 0 ; i < names.size(); i ++){
            if(names.get(i).equals(name)){
                names.remove(i);
                values.remove(i);
            }
        }
    }

    public String toCacheKey(String url){
        StringBuilder sb = new StringBuilder();
        sb.append(url).append("_");
        if(names != null && names.size() > 0) {
            for(int i = 0; i < names.size() ; i ++){
                sb.append(names.get(i)).append("_").append(values.get(i));
            }
        }
        return sb.toString();
    }

    public FormBody toFormBody(){
        FormBody.Builder param = new FormBody.Builder();
        if(names != null && names.size() > 0) {
            for(int i = 0; i < names.size() ; i ++){
                param.add(names.get(i), values.get(i));
            }
        }
        return param.build();
    }
}
