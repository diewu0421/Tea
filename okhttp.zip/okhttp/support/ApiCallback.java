package com.zx.tianditong.api.okhttp.support;

import android.os.Handler;
import android.os.Looper;

import com.zx.tianditong.api.okhttp.ApiResult;
import com.zx.tianditong.frame.App;
import com.zx.tianditong.util.MyLog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class ApiCallback implements Callback {
    private ApiResult result = null;
    private IResultHandler handler;
    private Handler mainHandler;

    private int cachedSecond;
    private ApiParams params;
    private String shortUrl;

    public ApiCallback(IResultHandler handler, ApiParams params, String shortUrl, int cachedSecond) {
        this.cachedSecond = cachedSecond;
        this.handler = handler;
        this.params = params;
        this.shortUrl = shortUrl;
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    @Override
    public void onFailure(Call call, IOException e) {
        setResult(ApiResult.error("服务异常:" + e.getMessage())); //示例
        sendResult();
    }

    @Override
    public void onResponse(Call call, Response response) throws IOException {
        try {
            if (response.isSuccessful()) {
                String content = response.body().string();
                result = JsonToResult(content);
                if (result != null && !result.isSuccess()) { // 处理特殊的错误
                    int code = result.getCode();
//                    if (code == 4001) {
//                    }
                }
                setResult(result);

                // 缓存
                if (cachedSecond >= 0 && result.isSuccess()) {
                    WebCached cached = new WebCached(App.getAppContext());
                    cached.setCache(params.toCacheKey(shortUrl), content);
                    cached.close();
                }
            } else {
                //setResult(AjaxResult.error("请求失败:" + response.message()));
                sendResult();
            }

        } catch (Exception e) {
            MyLog.e(this, e);
        }
        sendResult();
    }

    public static ApiResult JsonToResult(String obj) {
        try {
            // ApiResult result = JSON.fromJson(obj, TypeToken.get(ApiResult.class));
            if(obj != null){
                try{
                    JSONObject data = new JSONObject(obj);
                    if(data.has("code") && data.has("remark")){
                        ApiResult result = new ApiResult();
                        result.setCode(data.getInt("code"));
                        result.setRemark(data.getString("remark"));
                        result.setNum(data.has("num")?data.getInt("num"):0);

                        try{
                            JSONObject dataContent = data.getJSONObject("data");
                            result.setData(dataContent);
                        }catch (Exception ex){
                            // 遗留问题，data是数组的情况
                            try{
                                JSONArray dataContent = data.getJSONArray("data");
                                JSONObject dataTemp = new JSONObject();
                                dataTemp.put("list",dataContent);
                                result.setData(dataTemp);
                            }catch (Exception ex1){
                            }
                        }
                        return result;
                    }else{
                        // 遗留问题，直接返回结果的情况
                        ApiResult result = ApiResult.success("正确");
                        result.setData(data);
                        return result;
                    }
                }catch (Exception ex){
                }

                // 遗留问题，返回0的情况
                if(obj.equals("0")){
                    return ApiResult.error("服务返回错误:"+obj);
                }else{
                    JSONObject dataTemp = new JSONObject();
                    dataTemp.put("value",obj);
                    ApiResult result = ApiResult.success("成功");
                    result.setData(dataTemp);
                    return result;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ApiResult.error("unknow:"+obj == null? "null":obj);
    }

    private void sendResult() {
        if (handler != null) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (result == null) {
                        result = new ApiResult();
                    }
                    handler.onResult(result);
                }
            });
        }
    }

    public ApiResult getResult() {
        return result;
    }

    public void setResult(ApiResult result) {
        this.result = result;
    }
}
