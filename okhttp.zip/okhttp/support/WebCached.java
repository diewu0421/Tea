package com.zx.tianditong.api.okhttp.support;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Date;

import okhttp3.FormBody;

public class WebCached {
	private static final String DATABASE_NAME = "tdt.webcached";
	private static final int DATABASE_VERSION = 1;
	private static final String PREF_TABLE_NAME = "webcached";

	private Context context;
	private SQLiteDatabase db;
	DatabaseHelper databaseHelper;

	public WebCached(Context context) {
		this.context = context;
		databaseHelper = new DatabaseHelper(context);
		open();
	}

	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);

		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// db.execSQL(TABLE_ACCOUNT_CREATE);
			db.execSQL("CREATE TABLE IF NOT EXISTS " + PREF_TABLE_NAME
					+ " (`key` TEXT PRIMARY KEY,`value` TEXT,`updDate` TEXT)");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		}
	}

	private boolean opened = false;

	private void open() {
		try {
			if (db == null || !opened) {
				db = databaseHelper.getWritableDatabase();
				opened = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void close() {
		databaseHelper.close();
		db = null;
		opened = false;
	}

	public boolean isOpen() {
		return opened;
	}

	public boolean contains(String key) {
		boolean result = false;
		try {
			Cursor cursor = db.rawQuery("SELECT `value` FROM "
					+ PREF_TABLE_NAME + " WHERE `key`='" + key + "'", null);
			result = cursor.moveToFirst();
			cursor.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;

	}

	public boolean delete(String key) {
		boolean result = false;
		try {
			result = db.delete(PREF_TABLE_NAME, "`key`='" + key + "'", null) > 0;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
//	public static String getKey(String url,RequestParams params){
//		StringBuilder sb = new StringBuilder();
//		sb.append(url).append("_").append(params == null?"null":params.toString());
//		return sb.toString();
//	}

	public static String getKey(String url, FormBody params){
		StringBuilder sb = new StringBuilder();
		sb.append(url).append("_");
		if(params != null && params.size() > 0) {
			for(int i = 0; i < params.size() ; i ++){
				sb.append(params.name(i)).append("_").append(params.value(i));
			}
		}
		return sb.toString();
	}

	public boolean setCache(String key, String value) {
		boolean result = false;
		try {
			if(key != null && value != null && value.length() > 0){
				ContentValues cv = new ContentValues();
				cv.put("value", value);
				cv.put("key", key);
				cv.put("updDate", new Date().getTime());
				if(contains(key))
					result = db.update(PREF_TABLE_NAME, cv, "`key`='" + key + "'", null) > 0;
				else
					result = db.insert(PREF_TABLE_NAME, null, cv) > 0;
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String getCache(String key,int second) {
		String result = null;
		try {
			Cursor cursor = db.rawQuery("SELECT `value`,`updDate` FROM "
					+ PREF_TABLE_NAME + " WHERE `key`='" + key + "'", null);
			if (cursor.moveToFirst()) {
				result = cursor.getString(0);
				long updDate = cursor.getLong(1);
				if(second != 0 && second * 1000 < new Date().getTime() - updDate){
					result = null;
				}
			}
			cursor.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
