package com.zx.tianditong.api.okhttp.support;

import com.zx.tianditong.api.okhttp.ApiResult;

public interface IResultHandler {
    void onResult(ApiResult result);
}
