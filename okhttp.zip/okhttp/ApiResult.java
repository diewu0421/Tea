package com.zx.tianditong.api.okhttp;

import org.json.JSONObject;

import java.io.Serializable;

public class ApiResult implements Serializable {

    private static final long serialVersionUID = 1L;

    private int num = 0;
    private int code = -1;
    private String remark = "";
    private JSONObject data;

    public ApiResult() {
    }

    public ApiResult(int code, String remark) {
        this.code = code;
        this.remark = remark;
    }

    /**
     * success:   2000 >= code >= 1
     * error :    code=0 or code > 2000
     *
     * @return
     */
    public boolean isSuccess() {
        return code > 0 && code <= 2000;
    }

    public static ApiResult error(String msg) {
        return new ApiResult(-1, msg);
    }

    public static ApiResult success(String msg) {
        return new ApiResult(1, msg);
    }


    public JSONObject getData() {
        return data;
    }

    public void setData(JSONObject data) {
        this.data = data;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
