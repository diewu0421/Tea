package com.zx.tianditong.api.okhttp;

public interface URL {
    //String baseUrl = "http://192.168.0.124:8080/";
    String baseUrl = "http://manager.1k8.com.cn/";
//    String baseUrl = "http://manager.chaohm.com:80/";  // 超惠买*

    String baseUrl_2 = "CarInternet/";

    // 首页切换 获取多店铺 &bussinessId=29
    String homeQiehUrl = "CarInternet/NewServlet.servlet?api=allShops";

    //支付宝 签名  &ordernumber=160805074371
    String pay_zfb = "CarInternet/WeixinServlet.servlet?api=alipayMd5";

    //我的优惠券  &memberId=1
    String youhui_my = "CarInternet/NewServlet.servlet?api=myCoupon";

    //领取优惠卷  &memberId=1  &couponId=3
    String youhui_get = "CarInternet/NewServlet.servlet?api=getCoupon";

    //领卷中心  &memberId=1
    String youhui_lqzx = "CarInternet/NewServlet.servlet?api=bussinessCoupon";

    //当前能使用的优惠卷(填写订单页面)  &bussinessId&money=&memberId=
    String dingdan_youhui = "CarInternet/NewServlet.servlet?api=useCoupon";

    //说明  &aboutId=
    String guanyu = "CarInternet/NewServlet.servlet?api=aboutById";


    //Find获取用户栏目
    String URL_FIND_USER_COLUMN = "CarInternet/api/Discover_userColumn.htm?";
    //Find 获取商家栏目   显示所有栏目;   &bussinessId=33   http://192.168.0.132:8080/CarInternet/api/Discover_discover.htm?&bussinessId=33
    String URL_FIND_SHOP_COLUMN = "CarInternet/api/Discover_discover.htm?";
    //新增用户栏目
    String URL_FIND_ADD_USER_COLUMN = "CarInternet/api/Discover_addUserColumn.htm?";
    //删除用户栏目
    String URL_FIND_DELETE_USER_COLUMN = "CarInternet/api/Discover_delUserColumn.htm?";

    //Find界面  推荐界面列表     &bussinessId=33   //    http://192.168.0.132:8080/CarInternet/api/Discover_recommend.htm?&bussinessId=33
    String URL_FIND_RECOMMEND = "CarInternet/api/Discover_recommend.htm?";
    //Find界面  除推荐栏目外 文章列表  http://192.168.0.132:8080/CarInternet/api/Discover_article.htm?&bussinessId=33&column
    String URL_FIND_ARTICLE = "CarInternet/api/Discover_article.htm?";
    //    String URL_FIND = "CarInternet/NewServlet.servlet?api=discover";
    //栏目下所有文章 ：&columnId=
//    {"code":"1","remark":"正确","data":{"columns":[{"columnId":2,"columnName":"123","columnBanner":"image/found/20160816/20160816_5472.jpg","columnContent":"3333123"},{"columnId":3,"columnName":"123","columnBanner":"image/found/20160816/20160816_9979.jpg","columnContent":"3333123"},{"columnId":4,"columnName":"123123","columnBanner":"image/found/20160816/20160816_3367.jpg","columnContent":"jalsdasdk"},{"columnId":5,"columnName":"123123","columnBanner":"image/found/20160816/20160816_3507.jpg","columnContent":"jalsdasdk"},{"columnId":6,"columnName":"2123","columnBanner":"image/found/20160816/20160816_5682.jpg","columnContent":"313123123"},{"columnId":7,"columnName":"2123","columnBanner":"image/found/20160816/20160816_8807.jpg","columnContent":"313123123"},{"columnId":8,"columnName":"123","columnBanner":"","columnContent":"123"},{"columnId":9,"columnName":"test","columnBanner":"image/found/20160816/20160816_2740.jpg","columnContent":"test"}]}}
//    String URL_FIND_ARTICLE = "CarInternet/NewServlet.servlet?api=getArticler";
    //    {"code":"1","remark":"正确","data":{"columns":[{"articleId":1,"articleTitle":"123123","createTime":{"date":22,"day":1,"hours":14,"minutes":9,"month":7,"nanos":0,"seconds":8,"time":1471846148000,"timezoneOffset":-480,"year":116},"hits":0,"collect":0,"updTime":0},{"articleId":2,"articleTitle":"12312313123","createTime":{"date":22,"day":1,"hours":14,"minutes":9,"month":7,"nanos":0,"seconds":8,"time":1471846148000,"timezoneOffset":-480,"year":116},"hits":0,"collect":0,"updTime":0},{"articleId":3,"articleTitle":"酒喝多了卡号拉开交话费爱肯定就是拉开就","createTime":{"date":22,"day":1,"hours":14,"minutes":9,"month":7,"nanos":0,"seconds":8,"time":1471846148000,"timezoneOffset":-480,"year":116},"hits":0,"collect":0,"updTime":0},{"articleId":4,"articleTitle":"123123123123","createTime":{"date":22,"day":1,"hours":14,"minutes":9,"month":7,"nanos":0,"seconds":8,"time":1471846148000,"timezoneOffset":-480,"year":116},"hits":0,"collect":0,"updTime":0}]}}
    //文章详情：  &articleId=
    String URL_FIND_ARTICLE_DETAIL = "CarInternet/api/Discover_articleById.htm?";

    //获取文章评论  http://manager.chaohm.com:80/CarInternet   itemId   next  number
    String URL_FIND_ARTICLE_COMMENT = "CarInternet/api/Discover_comment.htm?";
    //获取评论回复
    String URL_FIND_GET_COMMENT_REPLY = "CarInternet/api/Discover_commentReply.htm?";
    //添加评论
    String URL_FIND_ADD_COMMENT = "CarInternet/api/Discover_addComment.htm?";
    //添加评论回复
    String URL_FIND_ADD_COMMENT_REPLY = "CarInternet/api/Discover_addCommentReply.htm?";

    //更新文章浏览量
    String URL_FIND_ARTICLE_HITS = "CarInternet/api/Discover_articleHits.htm?";
    //收藏文章
    String URL_FIND_ARTICLE_COLLECT = "CarInternet/api/Discover_collectArticle.htm?";
    //取消收藏文章
    String URL_FIND_ARTICLE_COLLECT_CANCEL = "CarInternet/api/Discover_cancelCollectArticle.htm?";
    String URL_FIND_MY_COLLECTION = "CarInternet/api/Discover_articleByUserCollect.htm?";

    //订阅文章作者
    String URL_FIND_SUBSCRIPTION_WRITER = "CarInternet/api/Discover_subscriptWriter.htm?";
    //取消订阅文章作者
    String URL_FIND_CANCEl_SUBSCRIPTION_WRITER = "CarInternet/api/Discover_disSubscriptWriter.htm?";
    //根据用户订阅获取文章列表
    String URL_FIND_ARTICLELIST_BY_SUBSCRIBE = "CarInternet/api/Discover_getArticleBySubscript.htm?";

    //订单-自提  wuliustatus=  1快递 2自提    memberId=&status=
    String Order_Ziti = "CarInternet/api/Order_listOrder.htm?";

    //订单-自提  查看验证码  orderId
    String orderZt_yanzm = "CarInternet/api/Order_getCode.htm?";

    //订单-快递  确认收货   orderId
    String orderKd_okShouhuo = "CarInternet/api/Order_sureGet.htm?";

    //订单-待付款  取消订单   orderId
    String orderdDfk_quxiao = "CarInternet/api/Order_cancelOrder.htm?";


    //售后 售后申请  memberId
    String helpSh = "CarInternet/api/Order_returns.htm?";
    //售后 memberId=&status=  处理中 status=3  处理完成为 5
    String helpSh2 = "CarInternet/api/Product_check.htm?";

    //待评价  memberId
    String daipingj = "CarInternet/api/Order_waitForEvaluate.htm?";

    //订单详情  orderId
    String order_xq = "CarInternet/api/Order_orderDetail.htm?";
    //申请退货  orderDetailId=&reason=
    String order_shenqtuihuo = "CarInternet/api/Product_returnGoods.htm?";
    //催促  orderId=1407
    String order_cuicu = "CarInternet/api/Order_beQuick.htm?";
    //写评价  content=1694-3-不错&memberId=   content  由orderDetailId-评价等级-内容组成
    String xiepingj = "CarInternet/api/Product_evaluate.htm?";
    //查询物流  orderId
    String wuliu = "CarInternet/api/Order_findExpress.htm?";

    //根据店铺ID 查询店铺名称  &bid=
    String cxBidName = "CarInternet/WeixinServlet.servlet?api=findBussinessMemberByBussinessID";

    //获取自提点   bussinessId
    String getZitid = "CarInternet/api/Member_showAddress.htm?";

    //通知 消息盒子  memberId
    String tongzhi = "CarInternet/api/Member_reportNum.htm?";

    //通知 根据类型显示 具体消息  memberId  type
    String tongzhi_type = "CarInternet/api/Member_report.htm?";

    //直接购买  new     addressId  delivery_method  memberId  prodetailId  productBussinessId  pronum
    String oneShop = "CarInternet/api/Buy_buy.htm?";

    //购物车购买 new     shoppingcarIds  addressId
    String goucarShop = "CarInternet/api/Buy_shoppingcarBuy.htm?";

    //选择发票自提点  addressId  copyOrderId  couponInfoId
    String click_fpztd = "CarInternet/api/Buy_updateCopyOrder.htm?";

    //根据虚拟订单ID查询数据  copyOrderIds  addressId
    String chaxunXlOrder = "CarInternet/api/Buy_detailByCopyOrderId.htm?";

    //购买指南  产品说明列表   type  1，商城端 2，采购端
    String shuomlist = "CarInternet/api/Discover_about.htm?";

    //提交订单 new   addressId  copyOrderIds  receiptId  remark
    String tijiaoDD = "CarInternet/api/Buy_createOrder.htm?";

    //充值 充值卡充值   cashNum cashPass memberId
    String chongzhi_card = "CarInternet/api/Member_recharge.htm?";

    //支付 余额支付   memberId orderNums payMoney
    String zhifu_yu_e = "CarInternet/pay/callback/Pay_BalancePay.htm?";

    //我的钱包   memberId
    String my_qianbao = "CarInternet/api/Member_myPurse.htm?";

}
