package com.zx.tianditong.api.okhttp;


import com.franmontiel.persistentcookiejar.ClearableCookieJar;
import com.franmontiel.persistentcookiejar.PersistentCookieJar;
import com.franmontiel.persistentcookiejar.cache.SetCookieCache;
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor;
import com.zx.tianditong.api.okhttp.support.ApiCallback;
import com.zx.tianditong.api.okhttp.support.ApiParams;
import com.zx.tianditong.api.okhttp.support.IResultHandler;
import com.zx.tianditong.api.okhttp.support.WebCached;
import com.zx.tianditong.frame.App;
import com.zx.tianditong.util.MyLog;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class API {

	private static final int DEFAULT_TIMEOUT = 40;

	public static void post(String url, ApiParams params, IResultHandler handler) {
		post(url, params, -1, -1,handler);
	}

	public static ApiResult post(String url, ApiParams params) {
		return post(url, params,-1, -1);
	}

	public static void post(String url, ApiParams params,int cachedSecond, IResultHandler handler) {
		post(url, params, cachedSecond, -1,handler);
	}

	public static ApiResult post(String url, ApiParams params, int cachedSecond) {
		return post(url, params,cachedSecond, -1);
	}


	// 异步方式
	public static void post(String url,ApiParams params,int cachedSecond,int timeoutSecond, IResultHandler handler){
		String result = null;
		if(params == null){
			params = new ApiParams();
		}
		if(cachedSecond > 0){
			WebCached cached = new WebCached(App.getAppContext());
			result = cached.getCache(params.toCacheKey(url), cachedSecond);
			cached.close();
		}
		OkHttpClient client = getHttpClient(timeoutSecond,URL.baseUrl.startsWith("https"));
		boolean cachedUsed = false;
		if (result != null) {
			try {
				handler.onResult(ApiCallback.JsonToResult(result));
				cachedUsed = true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (!cachedUsed) {
			Request request = new Request.Builder().url(getAbsoluteUrl(url)).post(params.toFormBody()).build();
			client.newCall(request).enqueue(new ApiCallback(handler, params, url,cachedSecond));
		}
	}

	// 同步方式
	public static ApiResult post(String url, ApiParams params, int cachedSecond, int timeoutSecond){
		String result = null;
		if(params == null){
			params = new ApiParams();
		}
		if(cachedSecond > 0){
			WebCached cached = new WebCached(App.getAppContext());
			result = cached.getCache(params.toCacheKey(url), cachedSecond);
			cached.close();
		}

		OkHttpClient client = getHttpClient(timeoutSecond,URL.baseUrl.startsWith("https"));

		if (result != null) {
			try {
				return ApiCallback.JsonToResult(result);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Request request = new Request.Builder().url(getAbsoluteUrl(url)).post(params.toFormBody()).build();
		try {
			Response resp = client.newCall(request).execute();
			ApiCallback callback = new ApiCallback(null, params, url,cachedSecond);
			callback.onResponse(null,resp);
			return callback.getResult();
		} catch (IOException e) {
			MyLog.e(url,e);
			return ApiResult.error(e.getMessage());
		}
	}

	// 异步方式
	public static void postFile(String url, ApiParams params,File file,String mediaType,int timeoutSecond,IResultHandler handler){
		if(params == null){
			params = new ApiParams();
		}

		OkHttpClient client = getHttpClient(timeoutSecond,URL.baseUrl.startsWith("https"));

		MultipartBody.Builder builder = new MultipartBody.Builder();
		builder.setType(MultipartBody.FORM);
		if(params != null){
			for(int i = 0 ; i < params.size(); i ++){
				builder.addFormDataPart(params.getName(i),params.getValue(i));
			}
		}
		builder.addFormDataPart("file", file.getName(), RequestBody.create(MediaType.parse(mediaType), file));

		Request request = new Request.Builder().url(getAbsoluteUrl(url)).post(builder.build()).build();
		client.newCall(request).enqueue(new ApiCallback(handler, params, url,0));
	}

	// 同步方式
	public static ApiResult postFile(String url, ApiParams params, File file, String mediaType, int timeoutSecond){
		if(params == null){
			params = new ApiParams();
		}

		OkHttpClient client = getHttpClient(timeoutSecond,URL.baseUrl.startsWith("https"));

		MultipartBody.Builder builder = new MultipartBody.Builder();
		builder.setType(MultipartBody.FORM);
		if(params != null){
			for(int i = 0 ; i < params.size(); i ++){
				builder.addFormDataPart(params.getName(i),params.getValue(i));
			}
		}
		builder.addFormDataPart("file", file.getName(), RequestBody.create(MediaType.parse(mediaType), file));

		Request request = new Request.Builder().url(getAbsoluteUrl(url)).post(builder.build()).build();
		try {
			Response resp = client.newCall(request).execute();
			ApiCallback callback = new ApiCallback(null, params, url,0);
			callback.onResponse(null,resp);
			return callback.getResult();
		} catch (IOException e) {
			MyLog.e(url,e);
			return ApiResult.error(e.getMessage());
		}
	}

	public static String getAbsoluteUrl(String relativeUrl) {
		if(relativeUrl.startsWith("http")){
			return relativeUrl;
		}else{
			return URL.baseUrl + relativeUrl;
		}
	}


	// commit test
	private static ClearableCookieJar cookieJar = null;
	private static OkHttpClient getHttpClient(int timeoutSecond,boolean withSSL){
		try {
			if(cookieJar == null){
                cookieJar = new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(App.getAppContext()));
            }

			int timeout = DEFAULT_TIMEOUT;
			if(timeoutSecond != -1){
                timeout = timeoutSecond;
            }


			OkHttpClient.Builder builder = new OkHttpClient.Builder();
			if(withSSL){
                final TrustManager[] trustAllCerts = new TrustManager[] {
                        new X509TrustManager() {
                            @Override
                            public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType){
                            }
                            @Override
                            public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType){
                            }
                            @Override
                            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                return new java.security.cert.X509Certificate[]{};
                            }
                        }
                };

                final SSLContext sslContext = SSLContext.getInstance("SSL");
                sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
                final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

                builder.sslSocketFactory(sslSocketFactory);
                builder.hostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, SSLSession session) {
                        return true;
                    }
                });
            }

			return  builder.connectTimeout(timeout, TimeUnit.SECONDS)
                    .writeTimeout(timeout, TimeUnit.SECONDS)
                    .readTimeout(timeout, TimeUnit.SECONDS)
                    .cookieJar(cookieJar)
                    .build();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
